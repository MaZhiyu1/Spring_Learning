package com.tutorial.config;


import com.tutorial.bean.Vehicle;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;



/*
Spring @Configuration annotation is part of the spring core framework.
Spring Configuration indicates that the class has @Bean definition
methods. So Spring container can process the class and generate Spring Beans
to be used in the application.
 */
@Configuration
public class ProjectConfig {


    /*
    @Bean annotation, which lets Spring know that
    it needs to call this method when it initializes
    its context and adds th returned value to the context

     */

    @Bean(name="audiVehicle")
    Vehicle vehicle1(){
        var veh = new Vehicle();
        veh.setName("Audi");
        return veh;
    }
    /*
    The method names usually follow verbs notation. But for
    methods which we will use to create beans, can use nouns as names.
    */

    @Bean(value = "hondaVehicle")
    Vehicle vehicle2(){
        var veh = new Vehicle();
        veh.setName("Honda");
        return veh;
    }

    @Bean("ferrariVehicle")
    Vehicle vehicle3(){
        var veh = new Vehicle();
        veh.setName("Ferrari");
        return veh;
    }



}
